
<?php
// Create a blank image and add some text
session_start();

if (!isset($_SESSION["user"])||!isset($_GET['sure'])||!isset($_GET['password'])) {
    echo json_encode(array(
        "errorCode"=>"1002",
        "message"=>"Login first !"
    
    ));
} else { // select profilePic from users where userId == 'USER00024' ;

try{
    $sure = $_GET['sure'];
    $password =$_GET['password'];
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "users";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    
    $result = $bucket->get($user->email)->value;
    $result->isActive = false;
    $result->lastModified = time();
    $result->profilePic = "../img/userIcon.png";
    
    if(strcmp($sure ,"true")===0&&strcmp(hash("haval160,4", hash("sha256", $password)),$user->password)===0){
        $bucket->upsert($user->email,$result);
        echo json_encode(array(
            "errorCode"=>"1000",
            "message"=>"Success"
        
        ));

        session_unset();
        
        
    }else{
        echo json_encode(array(
            "errorCode"=>"1002",
            "message"=>"Incorrect Password."
        
        ));
        
    }

    

}catch(\Exception $e){
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));
   
    session_unset();
    

}
}
//imagestring($im, 1, 5, 5,  'A Simple Text String', $text_color);

// Set the content type header - in this case image/jpeg

// Output the image
//////imagepng($im);

// Free up memory
//imagedestroy($im);
?>
