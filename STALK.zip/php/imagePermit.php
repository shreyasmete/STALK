<?php
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$visibility = null;
@$members = $request->members;
@$imageIds = $request->imageIds;
$user = null;
$user=$_SESSION["user"];
if(sizeof($members)<=0)
    $visibility="p";
else{
    $visibility="custom"; 
    array_push($members, $user->userId); 
}   
try {

    $bucketName = "images";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
if(isset($_SESSION["user"])){
   

    foreach($imageIds as $imageId){
        $imageDoc = $bucket->get($imageId)->value;
        if($visibility =="p")
        $imageDoc->members =array();
        else
        $imageDoc->members = $members;
        $bucket->upsert($imageId,$imageDoc);
    }
    echo json_encode(array(
        "errorCode"=>1000,
        "message"=>"Success"
    
    ));
    die();

}
else{
    echo json_encode(array(
        "errorCode"=>1002,
        "message"=>"Fatal error"
    
    ));
}

}catch(\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
}    




?>