<?php

session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
if(isset($_SESSION["user"])){
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $query = CouchbaseN1qlQuery::fromString("select f.firstName ||' '|| f.lastName as name,comments,firstName,lastName,title,f.forum,forumId,lastModified,members,members as oldMembers,userId,visibility from forum as f where `email`LIKE'%%' AND documentType='forumDocument' AND (visibility='public' OR   (visibility='custom'  AND   array_contains(members,'".$user->userId."'))) ORDER BY lastModified ;");
    
    $result = $bucket->query($query)->rows;
    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1000",
        "message"=>"Success",
        "data"=>$result
    
    ));
    echo $newData;


}
else{
   
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $query = CouchbaseN1qlQuery::fromString("select f.firstName ||' '|| f.lastName as name,firstName,lastName,title,f.forum,forumId,lastModified,userId,visibility from forum as f where `email`LIKE'%%' AND documentType='forumDocument' AND visibility='public' ORDER BY lastModified ;");
    $query->positionalParams(array(9));
    $result = $bucket->query($query)->rows;
    
    
    
    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1000",
        "message"=>"Success",
        "data"=>$result
    
    ));
    echo $newData;
}
}catch(\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
}
?>