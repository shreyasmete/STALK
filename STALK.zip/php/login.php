<?php
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
    $bucketName = "users";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);
    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
   
    if (!isset($_SESSION["user"])) {
        @$email = strtolower($request->email);
        @$pass = $request->password;

        $user = $bucket->get($email)->value; //"password" => hash("haval160,4",hash("sha256", $pass)),
        if ($user->password == hash("haval160,4", hash("sha256", $pass))) {
            $user->isActive = true;
            
            $bucket->upsert($email, $user);
            //$user->password = "";

            session_unset();
            $_SESSION["user"] = $user;
            //$user->profilePic ="";
            
            echo json_encode(array(
                "errorCode" => 1000,
                "message" => "Success",
                "data" => array(
                    "email" => $user->email,
                    "password" => " ", 
                    "mobile" => $user->mobile,
                    "firstName" => $user->firstName,
                    "lastName" => $user->lastName,
                    "userTitle" => $user->userTitle,
                    "userId" => $user->userId,
                    "discription"=>$user->discription,
                    "myContact" => $user->myContact,
                    
                    "profilePic"=>" "
                )

                
            ));

        } else {
            echo json_encode(array(
                "errorCode" => 404,
                "message" => "Email or password is incorrect",

            ));
        }
    } else {
        $user1 = array();
        $user1 = $bucket->get($_SESSION["user"]->email)->value;
        if ($user1->isActive == true) {
            $_SESSION["user"]=$user1;
            echo json_encode(array(
                "errorCode" => 1000,
                "message" => "Success",
                "data" => array(
                    "email" => $user1->email,
                    "password" => " ", 
                    "mobile" => $user1->mobile,
                    "firstName" => $user1->firstName,
                    "lastName" => $user1->lastName,
                    "userTitle" => $user1->userTitle,
                    "userId" => $user1->userId,
                    "discription"=>$user1->discription,
                    "myContact" => $user1->myContact,
                    "profilePic"=>" "
                )

            ));
        } else {
            session_unset();
            //session_destroy();
        }
    }
} catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));
    session_unset();
    

}
