<?php
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {

    @$opassword = $request->opassword;
    @$mobile = $request->mobile;
    @$npassword = $request->npassword;
    @$discription = $request->discription;
    @$usertitle = $request->gender;

    $bucketName = "users";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    if (isset($_SESSION["user"])) {
        $old = array();
        $old = $_SESSION["user"];
        $olduser = $bucket->get($old->email)->value;
        if (  strcmp($npassword,"") ===0) {
            $npassword = $opassword;
        }

        $inputs = null;
        $inputs = array(
            "email" => $olduser->email,
            "password" => hash("haval160,4", hash("sha256", $npassword)),
            "mobile" => $mobile,
            "firstName" => $olduser->firstName,
            "lastName" => $olduser->lastName,
            "userTitle" => $usertitle,
            "userId" => $olduser->userId,
            "documentType" => "userDocument",
            "isActive" => true,
            "profilePic"=>$olduser->profilePic,
            "lastModified"=>time(),
            "discription"=>$discription,
            "myContact" => $olduser->myContact
            
        );
        
        if (strcmp(hash("haval160,4", hash("sha256", $opassword)),$olduser->password)===0) {
            $bucket->upsert($olduser->email, $inputs);
            $temp = $bucket->get($olduser->email)->value;
            echo json_encode(array(
                "errorCode" => 1000,
                "message" => "Success",
                "data" => array(
                    "email" => $temp->email,
                    "password" => " ", 
                    "mobile" => $temp->mobile,
                    "firstName" => $temp->firstName,
                    "lastName" => $temp->lastName,
                    "userTitle" => $temp->userTitle,
                    "userId" => $temp->userId,
                    "discription"=>$temp->discription,
                    "myContact" => $temp->myContact,
                    "profilePic"=>" "
                )
            ));
            
            session_unset();
            $_SESSION["user"] = $temp;

        }
        else {
            echo json_encode(array(
                "errorCode" => 1003,
                "message" => "Incorrect Password",
    
            ));
        }
    } else {
        echo json_encode(array(
            "errorCode" => 1002,
            "message" => "Unauthenticated action",

        ));
    }
} catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));

}
