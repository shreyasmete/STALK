<?php
session_start();
try {
   if(isset($_FILES['image']) && isset($_SESSION["user"])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $userId = null;
      if(isset($_POST['userId']))
      $userId = $_POST['userId'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      
      $extensions= array("text","txt","doc","docx","zip","aif","cda","mid","midi","mp3","wav","xml","psd","pdf","ppt","pptx","xlr","xls","xlsx","mp4","3gp","mkv","rtf");
      
      if(in_array($file_ext,$extensions)=== false){
         $errors[]="extension not allowed, please choose a text,txt,doc,docx,zip,aif,cda,mid,midi,mp3,wav,xml,psd,pdf,ppt,pptx,xlr,xls,xlsx,mp4,3gp,mkv or rtf";
      }
      
      if($file_size > 20097152){
         $errors[]='File size must be less than 20 MB';
      }
      
      if(empty($errors)==true){
         $bucketName = "images";
         $clusterLogs5 = "couchbase://localhost";
         $authenticator = new \Couchbase\PasswordAuthenticator();
         $authenticator->username('admin')->password('admin123');
         $cluster = new CouchbaseCluster($clusterLogs5);
     
         $cluster->authenticate($authenticator);
         $bucket = $cluster->openBucket($bucketName);
         $imageId = $bucket->get('newImageId')->value->id;
         $imageId = $imageId+ 1;
         $bucket->upsert('newImageId', array(
             "id" => $imageId,
         ));
         


         $user = null;
         $user=$_SESSION["user"];
         $storageUrl = null;
         $storageUrl ="../../../images/".time().$file_name;
         move_uploaded_file($file_tmp,$storageUrl);
        
         if($userId !==null){
            $bucket->insert("IMAGE000".$imageId,array(
                 "storageUrl" =>$storageUrl,
                 "userId" =>  $user->userId,
                 "members" =>array($user->userId,$userId)
               
            ));
         }else{
            $bucket->insert("IMAGE000".$imageId,array(
               "storageUrl" =>$storageUrl,
               "userId" =>  $user->userId,
               "members" =>array()
             
          ));
         }

         echo json_encode(array(
            "errorCode"=>1000,
            "message"=>"Success",
            "data"=> "IMAGE000".$imageId 
        ));
      }else{
         
         echo json_encode(array(
            "errorCode"=>1001,
            "message"=>"file not correct",
            "data"=>$errors
        ));
      }
   }
   else{
       
        echo json_encode(array(
            "errorCode"=>1001,
            "message"=>"file not set"
        
        ));
       
   }
}catch(\Exception $e) {
   //echo json_encode($e->getMessage());
   echo json_encode(array(
       "errorCode"=>$e->getCode(),
       "message"=>$e->getMessage()
   
   ));
}
?>
