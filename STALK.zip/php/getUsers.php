
<?php
// Create a blank image and add some text
session_start();

if (!isset($_SESSION["user"])) {
   
} else { // select profilePic from users where userId == 'USER00024' ;

try{
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $query = CouchbaseN1qlQuery::fromString("select false as isConnected,discription,lastModified,firstName || ' '||lastName as name,['img/userpicloading.gif'] as profilePic ,userId, userTitle from users where userId != '"."$user->userId"."' AND documentType=='userDocument' AND isActive==true;");
    //select firstName || ' '||lastName as name ,userId, userTitle from users where userId == 'USER00024' AND documentType=='userDocument' AND isActive==true;
    $result = $bucket->query($query)->rows;
    if(sizeof($result)==0)
     {
        echo json_encode(array(
            "errorCode"=>"1002",
            "message"=>"Unauthorised Action"
        
        ));
        die();
     }

   

    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1000",
        "message"=>"Success",
        "data"=>$result
    
    ));
    echo $newData;
    $_SESSION["allUsers"]=$newData;
}catch(\Exception $e){
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));

}
}
//imagestring($im, 1, 5, 5,  'A Simple Text String', $text_color);

// Set the content type header - in this case image/jpeg

// Output the image
//////imagepng($im);

// Free up memory
//imagedestroy($im);
?>
