<?php
session_start();
try {

    if (isset($_FILES['image']) && isset($_SESSION["user"])) {
        $errors = array();
        $file_name = $_FILES['image']['name'];
        $file_size = $_FILES['image']['size'];
        $file_tmp = $_FILES['image']['tmp_name'];
        $file_type = $_FILES['image']['type'];
        $file_ext = strtolower(end(explode('.', $_FILES['image']['name'])));

        $extensions = array("jpeg", "jpg", "png","gif");
        
        if (in_array(strtolower($file_ext), $extensions) === false) {
            $errors['extError'] = "please choose a JPEG, PNG or GIF file.";
        }

        if ($file_size > 2097152) {
            $errors['sizeErr'] = 'File size must be less than 2 MB';
        }

        if (empty($errors) == true) {
            $storageUrl = null;
            $storageUrl = "../../../images/" . time() . $file_name;
            move_uploaded_file($file_tmp, $storageUrl);
            $bucketName = "users";
            $clusterLogs5 = "couchbase://localhost";
            $authenticator = new \Couchbase\PasswordAuthenticator();
            $authenticator->username('admin')->password('admin123');
            $cluster = new CouchbaseCluster($clusterLogs5);
            $cluster->authenticate($authenticator);
            $bucket = $cluster->openBucket($bucketName);
            $user = $bucket->get($_SESSION["user"]->email)->value;
            $user->profilePic = $storageUrl;
            $user->lastModified=time();
            $bucket->upsert($_SESSION["user"]->email, $user);
            $_SESSION["user"]->profilePic=$user->profilePic;
            echo json_encode(array(
                "errorCode" => 1000,
                "message" => "Success",

            ));
        } else {

            echo json_encode(array(
                "errorCode" => 1001,
                "message" => "errors",
                "data" => $errors,
            ));
        }
    } else {

        echo json_encode(array(
            "errorCode" => 1001,
            "message" => "invalid request",

        ));

    }
} catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));
    session_unset();
    //session_destroy();
}
