<?php

session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
if(isset($_SESSION["user"])){
    @$forumId = $request->forumId;
    @$reportMsg = $request->reportMsg;
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "reports";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $result = array();
    $id = 0;
        $id = $bucket->get("newReportId")->value->id;
        $bucket->upsert("newReportId",array("id"=>$id+1));
        $bucket->insert("REPORT000".$id,
        array(
            "reportMsg"=>$reportMsg,
            "reporterId"=>$user->userId,
            "forumId"=>$forumId
        )
    
        );


    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1000",
        "message"=>"Success"
        
    
    ));
    echo $newData;

}
else{
    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1002",
        "message"=>"Invalid Request"
        
    
    ));
    echo $newData;
}
}catch(\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
}
?>