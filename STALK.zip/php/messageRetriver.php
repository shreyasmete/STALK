<?php
 session_start();
 $postdata = file_get_contents("php://input");
 $request = json_decode($postdata);
 try {
    if (isset($_SESSION["user"])){
        $bucketName = "messageQueues";
        $clusterLogs5 = "couchbase://localhost";
        $authenticator = new \Couchbase\PasswordAuthenticator();
        $authenticator->username('admin')->password('admin123');
        $cluster = new CouchbaseCluster($clusterLogs5);

        $cluster->authenticate($authenticator);
        $bucket = $cluster->openBucket($bucketName);

        $old = array();
        $old = $_SESSION["user"];
        try{
        $msgQueue = $bucket->get($old->userId)->value;
        }
        catch(\Exception $er){
            
                if($er->getCode() ===13){
                    $bucket->upsert($old->userId,array());
                    echo json_encode(array(
                        "errorCode" => 1000,
                        "message" => "Success",
                        "data" =>array()
                           
                    ));
                    die();
                    
                }
        }
        echo json_encode(array(
            "errorCode" => 1000,
            "message" => "Success",
            "data" =>$msgQueue
               
        ));

    }else{
        echo json_encode(array(
            "errorCode" => "1002",
            "message" => "Unauthorised Action",

        ));
        die();
    }


 } catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    
    
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));

}


?>