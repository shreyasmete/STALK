<?php
session_start();

try {
    $variable1 = "users";
    $variable2 = "couchbase://localhost";
    $variable3 = new \Couchbase\PasswordAuthenticator();
    $variable3->username('admin')->password('admin123');
    $variable4 = new CouchbaseCluster($variable2);

    $variable4->authenticate($variable3);
    $variable5 = $variable4->openBucket($variable1);
    if (!isset($_SESSION["user"])) {

    } else {
        $variable6 = $variable5->get($_SESSION["user"]->email)->value;
        if($variable6->isActive == true){
        
        }
        else{
           
            session_unset(); 
            //session_destroy();
        }
    }
} catch (\Exception $variable7) {
    //echo json_encode($variable7->getMessage());
    echo json_encode(array(
        "errorCode" => $variable7->getCode(),
        "message" => $variable7->getMessage(),

    ));
    session_unset(); 
    //session_destroy();

}
