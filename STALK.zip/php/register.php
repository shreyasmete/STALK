<?php
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
@$email = strtolower($request->remail);
@$pass = $request->rpassword;
@$mobile = $request->rmobile;
@$firstName = $request->rfirstName;
@$lastName = $request->rlastName;
@$usertitle = $request->gender;

$bucketName = "users";
$clusterLogs5 = "couchbase://localhost";
$authenticator = new \Couchbase\PasswordAuthenticator();
$authenticator->username('admin')->password('admin123');
$cluster = new CouchbaseCluster($clusterLogs5);

$cluster->authenticate($authenticator);
$bucket = $cluster->openBucket($bucketName);
$userId = $bucket->get('newUserId')->value;
$userId = $userId->id + 1;
$bucket->upsert('newUserId', array(
    "id" => $userId,
));
   
    
    $inputs = array(
        "email" => $email,
        "password" => hash("haval160,4",hash("sha256", $pass)), 
        "mobile" => $mobile,
        "firstName" => $firstName,
        "lastName" => $lastName,
        "userTitle" => $usertitle,
        "userId" => "USER000".$userId,
        "documentType" => "userDocument",
        "isActive" => true,
        "profilePic"=>"../img/userIcon.png",
        "lastModified"=>time(),
        "myContact" => array(),
        "discription"=>""
    );

    
    $bucket->insert($email, $inputs);
    $user = $bucket->get($email)->value;
    echo json_encode(array(
            "errorCode"=>1000,
            "message"=>"Success",
            "data" => array(
                "email" => $user->email,
                "password" => " ", 
                "mobile" => $user->mobile,
                "firstName" => $user->firstName,
                "lastName" => $user->lastName,
                "userTitle" => $user->userTitle,
                "userId" => $user->userId,
                "discription"=>$user->discription,
                "myContact" => $user->myContact,
                "profilePic"=>" "
            )
        ));
        session_unset(); 
        
        $_SESSION["user"]= $user;

        
} catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
    
}
