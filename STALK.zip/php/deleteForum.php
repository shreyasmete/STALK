
<?php
// Create a blank image and add some text
session_start();
$forumId = $_GET['forumId'];
if (!isset($_SESSION["user"])) {
    echo json_encode(array(
        "errorCode"=>"1002",
        "message"=>"You are not allowed to delete forum"
    
    ));
} else { // select profilePic from users where userId == 'USER00024' ;

try{
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    
    $result = $bucket->get($forumId)->value;
    $result->documentType = "deletedForumDocument";
    $result->lastModified = time();
    if(strcmp($result->userId,$user->userId)===0)
    {
        $bucket->upsert($forumId,$result);
        echo json_encode(array(
            "errorCode"=>"1000",
            "message"=>"Success"
        
        ));
    }
    else{
        echo json_encode(array(
            "errorCode"=>"1002",
            "message"=>"You are not allowed to delete forum"
        
        ));
        die();
    }

    

}catch(\Exception $e){
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));

}
}
//imagestring($im, 1, 5, 5,  'A Simple Text String', $text_color);

// Set the content type header - in this case image/jpeg

// Output the image
//////imagepng($im);

// Free up memory
//imagedestroy($im);
?>
