<?php
session_start();
session_unset();
session_destroy();
echo json_encode(array(
    "errorCode" => 1000,
    "message" => "Success",
    "data" => "User Logged out successfully",
));
?>