<?php

session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
if(isset($_SESSION["user"])){
    @$forumId = $request->forumId;
    @$comment = $request->comment;
    
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
 
    $result = $bucket->get($forumId)->value;
    array_push($result->comments,
        (object)array(
            "firstName" => $_SESSION["user"]->firstName,
            "lastName"=> $_SESSION["user"]->lastName,
            "comment"=> $comment,
            "time"=> time(),
            "userId" => $_SESSION["user"]->userId
          )

    );
    $result->lastModified=time();
    $bucket->upsert($forumId,$result);
    
    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1000",
        "message"=>"Success"
        
    
    ));
    echo $newData;
    $result2 = array();
    try{
        $bucket2 = $cluster->openBucket("notifications");
        $result2 = $bucket2->get($result->userId)->value;
    }catch(\Exception $er){
        if($er->getCode() ===13){
            $bucket2->upsert($result->userId,array());
        }
    }

    array_push($result2,
        (object)array(
            "userId"=> $_SESSION["user"]->userId,
            "time"=> time(),
            "name"=>$_SESSION["user"]->firstName,
            "comment"=>$comment,
            "forumId"=>$forumId,
            "title"=>$result->title,
            "documentType"=>"comment"
          )

    );
    
    $bucket2->upsert($result->userId,$result2);
    
}
else{

}
}catch(\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
}
?>