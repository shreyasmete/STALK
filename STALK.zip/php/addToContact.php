<?php
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
    @$userId = $request->userId;
    @$isConnected=$request->isConnected;
    if (isset($_SESSION["user"]) && isset($_SESSION["allUsers"])) {
        $bucketName = "users";
        $clusterLogs5 = "couchbase://localhost";
        $authenticator = new \Couchbase\PasswordAuthenticator();
        $authenticator->username('admin')->password('admin123');
        $cluster = new CouchbaseCluster($clusterLogs5);

        $cluster->authenticate($authenticator);
        $bucket = $cluster->openBucket($bucketName);

        $old = array();
        $old = $_SESSION["user"];
        $olduser = $bucket->get($old->email)->value;

        $query = CouchbaseN1qlQuery::fromString("select firstName ,lastName ,userId, userTitle from users where userId == '" . "$userId" . "' AND documentType=='userDocument' AND isActive==true limit 1;");
        //select firstName ,lastName ,userId, userTitle from users where userId == 'USER00024' AND documentType=='userDocument' AND isActive==true;
        $result = $bucket->query($query)->rows;
        if (sizeof($result) == 0) {
            echo json_encode(array(
                "errorCode" => "1002",
                "message" => "Unauthorised Action",

            ));
            die();
        }
        $arr = array(
            "firstName" => $result[0]->firstName,
            "lastName" => $result[0]->lastName,
            "userId" => $result[0]->userId,
            "userTitle" => $result[0]->userTitle,
            "time" => time().$result[0]->userId,
        );
        $index = null;
        $index = 0;
        $isKey = null;
        
        function findKey($array, $keySearch)
        {   $index = 0;
            foreach($array as $user){
                $index = $index+1;
                if(strcmp( $user->userId,$keySearch)===0){
                    return true;
                }
            }
            $index = -1;
            return false;
        }
        $isKey = findKey($olduser->myContact, $userId);
        if (!$isKey && !$isConnected) {
            array_push($olduser->myContact,
                (object) $arr);
        } else if($isKey && $isConnected && $index >-1){
            //unset($olduser->myContact[$index]);
            $newContacts = array();
            foreach($olduser->myContact as $remain){
                $index = $index+1;
                if(strcmp( $remain->userId,$userId)!==0){
                    array_push($newContacts,
                    (object) $remain);
                }

            }
            $olduser->myContact = $newContacts;
        }else if($isKey && !$isConnected){
            echo json_encode(array(
                "errorCode" => "1002",
                "message" => "Contact already exists",

            ));
            die();
        }else{
            echo json_encode(array(
                "errorCode" => "1002",
                "message" => "Something went wrong",

            ));
            die();
        }

        $bucket->upsert($olduser->email, $olduser);
        $temp = $bucket->get($olduser->email)->value;

        echo json_encode(array(
            "errorCode" => 1000,
            "message" => "Success",
            "data" =>$arr
               
        ));
        session_unset();
        $_SESSION["user"] = $temp;





$result2 = array();
    try{
        $bucket2 = $cluster->openBucket("notifications");
        $result2 = $bucket2->get($userId)->value;
    }catch(\Exception $er){
        if($er->getCode() ===13){
            $bucket2->upsert($userId,array());
        }
    }

    array_push($result2,
        (object)array(
            "userId"=> $_SESSION["user"]->userId,
            "time"=> time(),
            "firstName"=>$_SESSION["user"]->firstName,
            "lastName"=>$_SESSION["user"]->lastName,
            "documentType"=>"addToContacts"
          )

    );
    
    $bucket2->upsert($userId,$result2);








    } else {
        echo json_encode(array(
            "errorCode" => 1002,
            "message" => "Unauthenticated action",

        ));
    }

} catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));

}
