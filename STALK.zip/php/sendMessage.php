<?php

session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
if(isset($_SESSION["user"])){
    @$userId = $request->userId;
    @$message = $request->message;
    @$fileUrl = $request->fileUrl;
    @$file = $request->file;
    $user = null;
    $user=$_SESSION["user"];
    $bucketName = "messageQueues";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $result = array();
    try{
        $result = $bucket->get($userId)->value;
    }catch(\Exception $er){
        if($er->getCode() ===13){
            $bucket->upsert($userId,array());
        }
    }
    //send message
    array_push($result,
        (object)array(
            "userId"=> $user->userId,
            "time"=> time().$user->userId,
            "data"=> array(
            "message"=> $message,
            "sender"=> $user->userId,
            "isfile"=> $file,
            "fileUrl"=> $fileUrl)
          )

    );
    
    $bucket->upsert($userId,$result);
     
    //update my queue
    $result = $bucket->get($user->userId)->value;
    
    array_push($result,
        (object)array(
            "userId"=> $userId,
            "time"=> time().$userId,
            "data"=> array(
            "message"=> $message,
            "sender"=> $user->userId,
            "isfile"=> $file,
            "fileUrl"=> $fileUrl)
          )

    );
   
    $bucket->upsert($user->userId,$result);
    





    $newData = null;
    $newData = json_encode(array(
        "errorCode"=>"1000",
        "message"=>"Success"
        
    
    ));
    echo $newData;

}
else{

}
}catch(\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
}
?>