<?php

session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
@$forumId = $request->forumId;
$visibility = null;
@$members = $request->members;
try {
    if (isset($_SESSION["user"])) {
        $user = null;
        $user = $_SESSION["user"];
        $bucketName = "forum";
        $bucketName2 = "images";

        $clusterLogs5 = "couchbase://localhost";
        $authenticator = new \Couchbase\PasswordAuthenticator();
        $authenticator->username('admin')->password('admin123');
        $cluster = new CouchbaseCluster($clusterLogs5);

        $cluster->authenticate($authenticator);
        $bucket = $cluster->openBucket($bucketName);

        $result = $bucket->get($forumId)->value;

        if (strcmp($result->userId, $user->userId) === 0) {
            
            if (sizeof($members) <= 1) {
                $visibility = "public";
                $members = null;
                $members = array();
                
                
            } else {
                $visibility = "custom";

            }
            $result->members = $members;
            $result->visibility = $visibility;
            $bucket->upsert($forumId, $result);
            $bucket2 = $cluster->openBucket($bucketName2);
            foreach ($result->imageIds as $imageId) {
                $result2 = $bucket2->get($imageId)->value;
                $result2->members = $members;
                $bucket2->upsert($imageId, $result2);
            }

            echo json_encode(array(
                "errorCode" => "1000",
                "message" => "Success",
            ));
            die();

        } else {

            echo json_encode(array(
                "errorCode" => "1001",
                "message" => "Unauthorised Action",
            ));
            die();
        }

    } else {

        $newData = null;
        $newData = json_encode(array(
            "errorCode" => "1001",
            "message" => "Unauthorised Action",
        ));
        echo $newData;
        die();
    }
} catch (\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode" => $e->getCode(),
        "message" => $e->getMessage(),

    ));
}
