<?php

use ___PHPSTORM_HELPERS\object;
session_start();
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
try {
if(isset($_SESSION["user"])){
    @$forum = $request->forum;
    @$title = $request->title;
    @$imageIds = $request->imageIds;
    $visibility = null;
    @$members = $request->members;
    $user = null;
    $user=$_SESSION["user"];
    if(sizeof($members)<=0)
        $visibility="public";
    else{
        $visibility="custom"; 
        array_push($members, $user->userId); 
    }     
    
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $userId = $bucket->get('forumId')->value;
    $userId = $userId->id + 1;
    $bucket->upsert('forumId', array(
        "id" => $userId,
    ));
    $data= null;
    $data = array(
    "firstName"=>$user->firstName,
    "lastName"=>$user->lastName,
    
    "forumId"=>'FORUM000'.$userId,
    "email"=>$user->email,
    "userId"=>$user->userId,
    
    
    "forum"=>$forum,
    "title"=>$title,
    "visibility"=>$visibility,
    "members"=>$members,
    "lastModified" => time(),
    "documentType"=>'forumDocument',
    "comments" => array(),
    "imageIds" => $imageIds
);        
                

    $bucket->insert('FORUM000'.$userId,$data);
    echo json_encode(array(
        "errorCode"=>1000,
        "message"=>"Success",
        "data"=>$data
    ));
    


   


}else{
    echo json_encode(array(
        "errorCode"=>1001,
        "message"=>"Operation is not permitted",
        "data"=>''
    ));


}
}catch(\Exception $e) {
    //echo json_encode($e->getMessage());
    echo json_encode(array(
        "errorCode"=>$e->getCode(),
        "message"=>$e->getMessage()
    
    ));
}

?>