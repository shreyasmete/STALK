
<?php
// Create a blank image and add some text
session_start();

if (!isset($_SESSION["user"])) {
    header('Content-Type: image/jpeg');
    ob_clean();
    readfile('../../../images/generic.jpg');
} else { // select profilePic from users where userId == 'USER00024' ;

try{
    $url=null;
    $user = null;
    $user=$_SESSION["user"];
    if(isset($_GET['userId'])){
    $userId = $_GET['userId'];
  
    $bucketName = "forum";
    $clusterLogs5 = "couchbase://localhost";
    $authenticator = new \Couchbase\PasswordAuthenticator();
    $authenticator->username('admin')->password('admin123');
    $cluster = new CouchbaseCluster($clusterLogs5);

    $cluster->authenticate($authenticator);
    $bucket = $cluster->openBucket($bucketName);
    $query = CouchbaseN1qlQuery::fromString("select profilePic as pic from users where userId == '".$userId."' limit 1 ;");
    $result = $bucket->query($query)->rows;
    if(sizeof($result)!=1)
     {
        header('Content-Type: image/jpeg');
        ob_clean();
        readfile('../../../images/generic.jpg');
        die();
     }

     $url = $result[0]->pic;
    }
    else if(isset($_GET['imageId'])){
        $imageId =$_GET['imageId'];
        $bucketName = "images";
        $clusterLogs5 = "couchbase://localhost";
        $authenticator = new \Couchbase\PasswordAuthenticator();
        $authenticator->username('admin')->password('admin123');
        $cluster = new CouchbaseCluster($clusterLogs5);
    
        $cluster->authenticate($authenticator);
        $bucket = $cluster->openBucket($bucketName);
        $imageDoc = $bucket->get($imageId)->value;
        $url = null;
        foreach($imageDoc->members as $memb){
                if(strcmp($user->userId,$memb)===0)
                {
                    $url = $imageDoc->storageUrl;
                    break;
                }
                

        }
        if(sizeof($imageDoc->members)==0){
            $url = $imageDoc->storageUrl;
        }
        if($url == null){
            header('Content-Type: image/jpeg');
            ob_clean();
            readfile('../../../images/generic.jpg');
            die();
        }
        
    }else{
            die();
    }

    $ext = pathinfo($url, PATHINFO_EXTENSION);
    switch (strtolower($ext)) {
        case "jpg":
            header('Content-Type: image/jpeg');
            ob_clean();
            readfile($url);
            break;
        case "jpeg":
            header('Content-Type: image/jpeg');
            ob_clean();
            readfile($url);
            break;
        case "png":
            header('Content-Type: image/png');
            ob_clean();
            readfile($url);
            break;
        case "gif":
            header('Content-Type: image/gif');
            ob_clean();
            readfile($url);
            break;

        default:

        
if (file_exists($url)) {
    header('Expires: 0');
            header('Pragma: public');
            header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
            header('Content-Type: application/octet-stream');
            header('Content-Length: ' . sprintf('%u', filesize($url)));
            header('Content-Disposition: attachment; filename="' . basename($url) . '"');
            header('Content-Transfer-Encoding: binary');
    ob_clean();
    readfile($url);
    
    exit;
}else{
    die();
}
      

    }

}catch(\Exception $e){
    header('Content-Type: image/jpeg');
    ob_clean();
    readfile('../../../images/generic.jpg');

}
}
//imagestring($im, 1, 5, 5,  'A Simple Text String', $text_color);

// Set the content type header - in this case image/jpeg

// Output the image
//////imagepng($im);

// Free up memory
//imagedestroy($im);
?>
