var globalForum=[];

var app =
    angular.module('STALK', ['ngMaterial', 'textAngular']);

    app.config(function($provide){
        $provide.decorator('taOptions', ['taRegisterTool', 'taToolFunctions', '$delegate','$http','$window',function(taRegisterTool, taToolFunctions, taOptions,$http,$window){
            // $delegate is the taOptions we are decorating
            // register the tool with textAngular
            
            taRegisterTool('uploadImage', {
                iconclass: "fa fa-picture-o",
                tooltiptext: 'Upload an image',
                onElementSelect: {
                  element: 'img',
                  action: taToolFunctions.imgOnSelectAction
                },
                action: function() {
                  var $editor = this.$editor;
        
                  // Create a virtual input element.
                  var input = document.createElement('input');
                  input.type = 'file';
                  input.accept = "image/jpg,image/png,image/gif,image/jpeg";
        
                  input.onchange = function() {
                    var reader = new FileReader();
        
                    if (this.files && this.files[0]) {
                
                    var fd = new FormData();
                    //Take the first selected file
                    fd.append("image", this.files[0]);
        
                    $http.post("php/uploadImage.php", fd, {
                        withCredentials: true,
                        headers: { 'Content-Type': undefined },
                        transformRequest: angular.identity
                    }).success(function (data, status, headers, config) {
                        
                        if (data.message == "Success") {
                            $editor().wrapSelection('insertHtml', "<img alt='Login to see images' style='height:200px;width:200px' src='php/imageRetriver.php?imageId="+data.data+"'>", true);
                            globalForum.push(data.data);
                            //console.log(globalForum);
                        } else {
                            $window.alert("Something went wrong\n"+data.message);
                        }
        
                    }).error(function (data, status, headers, config) {
                        //console.log(data);
                        $window.location.reload();
                    });
                    }
                  };
        
                  // Click on a virtual input element.
                  input.click();
                }
              });
        
            // add the button to the default toolbar definition
            taOptions.toolbar[1].push('uploadImage');

            taRegisterTool('uploadFile', {
                iconclass: "fa fa-files-o",
                tooltiptext: 'Upload a File',
                onElementSelect: {
                  element: 'a',
                  action: taToolFunctions.aOnSelectAction
                },
                action: function() {
                  var $editor = this.$editor;
        
                  // Create a virtual input element.
                  var input2 = document.createElement('input');
                  input2.type = 'file';
                  //input2.accept = "*/*";
        
                  input2.onchange = function() {
                    
                    console.log("trying to upload");
                    if (this.files && this.files[0]) {
                    

                    
                    var fd = new FormData();
                    //Take the first selected file
                    fd.append("image", this.files[0]);
        
                    $http.post("php/uploadFile.php", fd, {
                        withCredentials: true,
                        headers: { 'Content-Type': undefined },
                        transformRequest: angular.identity
                    }).success(function (data, status, headers, config) {
                        // console.log(status + ' - ' + data);
                        // console.log("Error Code: " + data.errorCode)
                        // console.log("Error Message: " + data.message)
                        
                        if (data.message == "Success") {
                            $editor().wrapSelection('insertHtml', "<a target='_blank' href='php/imageRetriver.php?imageId="+data.data+"'>view file</a>", true);
                            globalForum.push(data.data);
                            console.log(globalForum);

                        } else {
                            $window.alert("Something went wrong "+ data.message);
                        }
        
                    }).error(function (data, status, headers, config) {
                        console.log(data);
                        $window.location.reload();
                    });
                    }
                  };
        
                  // Click on a virtual input element.
                  input2.click();
                  console.log("input file clicked");
                }
              });
        
            // add the button to the default toolbar definition
            taOptions.toolbar[1].push('uploadFile');

            return taOptions;
        }]);
    });


app.directive("forum", function () {
    var directive = {};
    directive.restrict = 'E'; //E=Element
    directive.template = "";

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        forum: "=name",
        index: "=index"
    }

    directive.compile = function (element, attributes) {

        element.css("margin-bottom", "1px");


        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {

            if ($scope.index == 0)
                element.html("<h1 style='color:blue' class='card-title'>" + $scope.forum.title + "</h5><p class='card-text'>" + $scope.forum.forum.substring(0, 50) + "...</p>");
            else
                element.html("<h1 style='color:blue' class='card-title'>" + $scope.forum.title + "</h5><p class='card-text'>" + $scope.forum.forum + "</p>");

        }
        return linkFunction;
    }

    return directive;
});

app.directive("file", function () {
    var directive = {};

    directive.restrict = 'E';
    directive.template = "";

    //scope is used to distinguish each student element based on criteria.
    directive.scope = {
        file: "=url",
        
    }

    directive.compile = function (element, attributes) {

        element.css("margin-bottom", "1px");
        //linkFunction is linked with each element with scope to get the element specific data.
        var linkFunction = function ($scope, element, attributes) {
                element.html($scope.file.data.fileUrl);
        }
        return linkFunction;
    }

    return directive;
});



app.controller('menuController',

    function ($filter, $http, $scope, $window, $mdDialog, textAngularManager) {
        var originatorEv;


        $scope.email = "";
        $scope.userImage = "img/userIcon.png";
        $scope.mobile = null;
        $scope.discription = null;
        $scope.firstName = "Guest";
        $scope.lastName = "";
        $scope.userId = "USER000";
        $scope.userTitle = "";
        $scope.menu1 = "settings";
        $scope.menu2 = "portrait";
        $scope.htmlContent = '<h2>Start typing here</h2>';

        $scope.wait = false;
        $scope.lrwait = false;
        
        $scope.isLoggedIn = false;
        $scope.loginError = "";
        $scope.forumdata = [];
        $scope.visibilityArray = [];
        $scope.refresh = true;
        $scope.myContacts = [
        ];

        $scope.users = [];

        $scope.setUserImage = function (userI, url) {
            var att = $scope.users.findIndex(temp => temp.userId === userI);

            if (att > -1) {
                ////console.log("userId and url " + att + " " + userI + " " + url);
                $scope.users[att].profilePic.pop();
                $scope.users[att].profilePic.unshift(url);
            }
        };

        $scope.getUserInboxImage =function(userId){
            if(userId === $scope.userId){
                return $scope.userImage;
            }
            var att = $scope.users.findIndex(temp => temp.userId === userId);

            if (att > -1) {
                ////console.log("userId and url " + att + " " + userId + " " + url);
                return $scope.users[att].profilePic[0];
            }
            return "img/userIcon.png";
        };

        $scope.myMsgQueue = [];

        this.openMenu = function ($mdOpenMenu, ev) {
            //console.log("clicked openmenu");
            originatorEv = ev;
            $mdOpenMenu(ev);
        };

        $scope.infocus = function (id,focus){
            //console.log("got focus "+id);
            var doc = document.getElementById(id);
            if(doc!=null)
            doc.style.color=(focus)?'blue':'black';
      }

        $scope.scroll = function (id) {
            setTimeout(function () {
                let scr = document.getElementById(id);
                scr.scrollTop = scr.scrollHeight;
            }, 100);
        };
        $scope.clickScroll = function (id) {
            setTimeout(function () {
                let scr = document.getElementById('scroll'+id);
                scr.scrollTop = scr.scrollHeight;
            }, 100);
        };
        

        this.manageVisib = function (userId, contacts) {
            if (!contacts) {
                var index = $scope.visibilityArray.indexOf(userId);
                $scope.visibilityArray.splice(index, 1);
                //console.log("vivibi popped ");
            }
            else {
                $scope.visibilityArray.push(userId);
                //console.log("vivibi pushed" + $scope.visibilityArray);
            }
        }

        $scope.tickCheck =function(userId){
            
            var index = $scope.visibilityArray.indexOf(userId);
            if(index>-1)
                return true;

            return false;
        }

        $scope.deactivateProfile =function(){
            var cnf =
            prompt("Are you sure that you want to deactivate this profile.\n"+
             "This will delete your user picture.\nTo reactivate profile just login again\n"+
             "Enter your password: " 
               , "");
            if($scope.isLoggedIn&&cnf!=null){
                    
                    $http.get('php/deactivateProfile.php', {
                        responseType: 'json',
                        params: { 
                            "sure": "true",
                            "password":cnf
                    
                    }
                    }).success(function (data) {
                        
                        if (data.message == "Success") {
                                $scope.message("Account is deactivated");
                                $window.location.reload();
                        }else{
                                $scope.message(data.message);
                        }
        
        
                    }).error(function (data, status, headers, config) {
                        //console.log(data);
                        $window.location.reload();
                    });
                }

        };

        // post forum function
        this.postForum = function (newForumTitle, newForum, visibi) {
            //console.log("title " + newForumTitle + "new forum data " + newForum);
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = {
                forum: newForum,
                title: newForumTitle,
                visibility: visibi,
                members: $scope.visibilityArray,
                imageIds:globalForum
            };

            $http.post('php/postForum.php', data)

                .success(function (data, status, headers, config) {

                    if (data.message == "Success") {
                        //$scope.myforumdata.unshift(data.data);
                        $scope.htmlContent = '<p></p>';
                        $scope.htmlContent = '<p></p>';
                        $scope.htmlContent = '<p></p>';
                        $scope.message("Forum Posted");
                    } else {
                        $window.location.reload();
                    }
                    //$scope.visibilityArray=[];
                })
                .error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                });


                data2 = {
                    
                    members: $scope.visibilityArray,
                    imageIds:globalForum
                };
    
                $http.post('php/imagePermit.php', data2)
    
                    .success(function (data, status, headers, config) {
                       
                        globalForum=[];
                        $scope.visibilityArray=[];
                        if (data.message == "Success") {
                            $scope.htmlContent = '<p></p>';
                            //$scope.message("visibility  Posted");
                        } else {
                            $window.location.reload();
                        }
                    })
                    .error(function (data, status, headers, config) {
                        //console.log(data);
                        $window.location.reload();
                    });
        };
        // post forum function end

        $scope.searchForum = function(tag){
            $scope.search = tag;
            console.log("tag is "+tag);
        }

        $scope.searchUser = function(tag){
            $scope.search = tag;
            console.log("tag is "+tag);
        };

        $scope.message = function (msg) {

            $mdDialog.show(
                $mdDialog.alert()
                    .title('STALK SAYS')
                    .textContent(msg)
                    .ok('OK')
                    .targetEvent(originatorEv)
            );
        };

        $scope.deleteForum = function (forumId) {
            $http.get('php/deleteForum.php', {
                responseType: 'json',
                params: { forumId: forumId }
            }).success(function (data) {
               
                if (data.message == "Success") {
                        $scope.message("Forum deleted !");
                }else{
                        $scope.message(data.message);
                }

            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
            });
        };

        $scope.deleteMyPost = function (forumId) {
            var cnf = $window.confirm("Are you sure you want to delete this forum?");
            if (cnf) {
                $scope.deleteForum(forumId);
            }
        };

        this.register = function (gender, rfirstName, rlastName, remail, rmobile, rpassword) {
            $scope.wait = true;
            $scope.lrwait=true;
            //console.log((gender + rfirstName + rlastName + remail + rmobile + rpassword));
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = {
                'gender': gender,
                'rfirstName': rfirstName,
                'rlastName': rlastName,
                'remail': remail,
                'rmobile': rmobile,
                'rpassword': rpassword
            };

            $http.post('php/register.php', data)

                .success(function (data, status, headers, config) {
                    $scope.loginError = " ";
                    if (data.message == "Success") {
                        $scope.email = data.data.email;

                        $scope.mobile = data.data.mobile;
                        $scope.firstName = data.data.firstName;
                        $scope.lastName = data.data.lastName;
                        $scope.userTitle = data.data.userTitle;
                        $scope.userId = data.data.userId;
                        $scope.discription = data.data.discription;
                        $scope.isLoggedIn = true;
                        $window.location.reload();
                    } else {
                        $scope.loginError = data.message;
                        console.log("Err Reg "+data.message);
                    }
                    $scope.lrwait=false;
                    $scope.wait=false;
                })
                .error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                    $scope.lrwait=false;
                    $scope.wait=false;
                });
            
        }

        this.login = function (lemail, lpassword) {
            $scope.wait = true;
            $scope.lrwait=true;
            //console.log(lemail + " " + lpassword);
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = {
                'email': lemail,
                'password': lpassword

            };

            $http.post('php/login.php', data)
                .success(function (data, status, headers, config) {
                    $scope.loginError = "";
                    if (data.message == "Success") {
                        $scope.email = data.data.email;
                        $scope.mobile = data.data.mobile;
                        $scope.firstName = data.data.firstName;
                        $scope.lastName = data.data.lastName;
                        $scope.userTitle = data.data.userTitle;
                        $scope.userId = data.data.userId;
                        $scope.isLoggedIn = true;
                        $scope.discription = data.data.discription;
                        $scope.myContacts = data.data.myContact;
                        $window.location.reload();
                    } else {
                        $scope.loginError = data.message;
                    }
                    $scope.wait = false;
                    $scope.lrwait=false;
                })
                .error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                    $scope.wait = false;
                    $scope.lrwait=false;
                });
        }

        this.setup = function () {
           
            //console.log("in setup" + new Date().getMilliseconds());
            $scope.wait = true;
            $scope.lrwait=true;
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            $http.post('php/login.php').success(function (data, status, headers, config) {
                if (data.message == "Success") {
                    $scope.email = data.data.email;
                    $scope.mobile = data.data.mobile;
                    $scope.firstName = data.data.firstName;
                    $scope.lastName = data.data.lastName;
                    $scope.userTitle = data.data.userTitle;
                    $scope.userId = data.data.userId;
                    $scope.discription = data.data.discription;
                    $scope.myContacts = data.data.myContact;
                    $scope.isLoggedIn = true;
                    $scope.getProfilePicture(data.data.userId);
                    // $scope.visibilityArray.push(data.data.userId);
                } else {
                }
    
                $scope.wait = false;
                $scope.lrwait=false;
            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
                $scope.wait = false;
                $scope.lrwait=false;
            });
            $scope.getForum();
            $scope.getUsers();
        };

        $scope.getUsers = function (isSetup) {
            if ($scope.isLoggedIn) {
                $scope.wait = true;
                $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
                $http.post('php/getUsers.php')
                    .success(function (data, status, headers, config) {
                    
                        if (data.message == "Success") {
                            //$scope.users=data.data;
                            angular.forEach(data.data, function (value, index) {

                                var at = $scope.users.findIndex(temp => temp.userId === data.data[index].userId);
                                if ((at) > -1) {
                                    if ($scope.users[at].lastModified !== data.data[index].lastModified) {
                                        $scope.getProfilePicture(data.data[index].userId);
                                        $scope.users[at].lastModified = data.data[index].lastModified;
                                    }
                                    //console.log("user already exists");
                                }
                                else {

                                    $scope.users.push(data.data[index]);
                                }
                            });

                          
                            angular.forEach($scope.users, function (value, index) {
                                $scope.users[index].isConnected = false;
                                var topop = data.data.findIndex(temp => temp.userId === $scope.users[index].userId);
                                if (topop === -1) {
                                    //console.log("delete forum " + index);
                                    $scope.users.splice(index, 1);
                                }
                            });

                            angular.forEach($scope.myContacts, function (value, index) {

                                var at = $scope.users.findIndex(temp => temp.userId === $scope.myContacts[index].userId);
                                if (at > -1) {
                                    $scope.users[at].isConnected = true;
                                }

                            });

                        } else {


                        }
                        $scope.wait = false;
                    })
                    .error(function (data, status, headers, config) {
                        //console.log(data);
                        $window.location.reload();
                        $scope.wait = false;
                    });
            }
        };

        $scope.getMyImage = function(){
            return $scope.userImage;
        }

        $scope.getProfilePicture = function (userId) {
            $scope.wait = true;
            
            if(userId===$scope.userId)
            $scope.userImage = "img/loading.gif";
            $http.get('php/imageRetriver.php', {
                responseType: 'arraybuffer',
                params: { "userId": userId }
            }).success(function (data) {

                var file = new Blob([data], {
                    type: 'image/jpeg'
                });
                var fileURL = URL.createObjectURL(file);
                var image = new Image();
                image.onerror = function () {
                    //console.log("error in image loader " + userId);
                    if (userId == $scope.userId) {
                        $scope.userImage = "img/userIcon.png";
                        
                    } else {
                        $scope.setUserImage(userId, "img/userIcon.png");
                    }
                };

                image.onload = function () {
                    ////console.log("image load is successful " + userId);
                    if (userId == $scope.userId) {
                        $scope.userImage = fileURL;
                        //console.log("variable is set "+$scope.userImage);
                       
                    } else {
                        //console.log("userId " + userId)
                        $scope.setUserImage(userId, fileURL);
                    }
                };

                image.src = fileURL;
                $scope.wait = false;
            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
            });
        };

        $scope.getForumTitle =function(tag){
            var ind = $scope.forumdata.findIndex(temp => temp.forumId === tag)
            if(ind>-1)
           return $scope.forumdata[ind].title;
           return 'Forum does not exists or you dont have permission';
        };


        $scope.isInMyContacts = function(userId){
            // console.log("name for user Id"+ userId);
            var att = $scope.myContacts.findIndex(temp => temp.userId === userId);
            if(att>-1)
               return true;
                return false;
        };
        $scope.getNameFromMyContacts = function(userId){
            // console.log("name for user Id"+ userId);
            var att = $scope.myContacts.findIndex(temp => temp.userId === userId);
            if(att>-1)
                {
                   return $scope.myContacts[att].firstName + " " + $scope.myContacts[att].lastName;
                }else{
                    var usr = $scope.users.findIndex(temp => temp.userId === userId);
                    if(usr>-1){
                        return $scope.users[usr].name;
                    }else{
                        return userId;
                    }
                }
                return userId;
        };

        $scope.copyArray = function(arr1,arr2){
            // arr1 = angular.copy(arr2);
            arr1.splice(0,arr1.length);
            angular.forEach(arr2,
                function (value, index) {
                    arr1.push(value);
                }
                
                );
        }

        $scope.getForum = function () {
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = { 'email': "", 'password': "" };
            $http.post('php/getForum.php', data).success(function (data, status, headers, config) {
                
                if (data.message == "Success") {
                    angular.forEach(data.data, function (value, index) {

                        var at = $scope.forumdata.findIndex(temp => temp.forumId === data.data[index].forumId);
                        if ((at) > -1) {
                            //console.log("title at : " + data.data[index].title);
                            if ($scope.forumdata[at].lastModified !== data.data[index].lastModified) {
                                //console.log("modified !!");
                                $scope.forumdata[at].forum = data.data[index].forum;
                                $scope.forumdata[at].title = data.data[index].title;
                                $scope.forumdata[at].lastModified = data.data[index].lastModified;
                                if (data.data[index].comments.length > 0 && $scope.isLoggedIn
                                    && data.data[index].comments.length !== $scope.forumdata[at].comments.length) {
                                    //console.log("new comment !!");
                                    data.data[index].comments = data.data[index].comments.sort(function (a, b) {
                                        return a.time - b.time;
                                    });


                                    for (var i = $scope.forumdata[at].comments.length; i < data.data[index].comments.length; i++) {
                                        $scope.forumdata[at].comments.push(
                                            data.data[index].comments[i]
                                        );
                                    }
                                }
                            }
                        }
                        else {
                            if ($scope.isLoggedIn)
                                data.data[index].comments = data.data[index].comments.sort(function (a, b) {
                                    return a.time - b.time;
                                });
                            $scope.forumdata.unshift(data.data[index]);

                        }
                    });
                    angular.forEach($scope.forumdata, function (value, index) {

                        var topop = data.data.findIndex(temp => temp.forumId === $scope.forumdata[index].forumId);
                        if (topop === -1) {
                            //console.log("delete forum " + index);
                            $scope.forumdata.splice(index, 1);
                        }
                    });

                } else {
                    $window.location.reload();
                }

            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
            });
            $scope.wait = false;

        };
        setInterval(function () {
            if ($scope.refresh) {
                //console.log("refresh Call");
                $scope.getForum();
                $scope.getUsers();

            } else {
                //console.log("refresh false");
            }
            $scope.$apply();
        }, 2500);
        setInterval(function () {
            if ($scope.refresh) {

                $scope.messageQueue();
                $scope.getNotifications();

            } else {
                //console.log("refresh false");
            }
            $scope.$apply();

        }, 1000);

        $scope.isInMyMsgQueue = function(id){
            var at = $scope.myMsgQueue.findIndex(temp => temp.userId === id);
            if ((at) > -1)
            return true;
                    
            return false;
        };












        $scope.notifications = [];
        $scope.getNotifications = function () {
            if ($scope.isLoggedIn) {
                $http.get('php/getNotification.php', {
                    responseType: 'json'
                }).success(function (data) {
               
                    if (data.message == "Success") {

                        angular.forEach(data.data, function (value, index) {

                            var at = $scope.notifications.findIndex(temp => temp.time === data.data[index].time);
                            if ((at) > -1) {

                                //console.log("message already exists");
                            }
                            else {
                                $scope.notifications.push(data.data[index]);
                                
                            }
                        });
                    }

                }).error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                });
            }
        }















        $scope.messageQueue = function () {
            if ($scope.isLoggedIn) {
                $http.get('php/messageRetriver.php', {
                    responseType: 'json'
                }).success(function (data) {
               
                    if (data.message == "Success") {

                        angular.forEach(data.data, function (value, index) {

                            var at = $scope.myMsgQueue.findIndex(temp => temp.time === data.data[index].time);
                            if ((at) > -1) {

                                //console.log("message already exists");
                            }
                            else {
                                $scope.myMsgQueue.push(data.data[index]);
                                var att = $scope.myContacts.findIndex(temp => temp.userId === data.data[index].userId);
                                if(att>-1)
                                {
                                    $scope.myContacts[att].time = data.data[index].time;
                                    tem = $scope.myContacts[att];
                                    $scope.myContacts.splice(att,1);
                                    $scope.myContacts.push(tem);
                                    $scope.scroll('scroll'+$scope.myContacts[att].userId);
                                }
                            }
                        });
                    }

                }).error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                });
            }
        }

        this.logout = function () {
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = {
                'email': "",
                'password': ""

            };

            $http.post('php/logout.php', data)

                .success(function (data, status, headers, config) {
                  
                    if (data.message == "Success") {
                        $mdDialog.show(
                            $mdDialog.alert()
                                .title('STALK SAYS')
                                .textContent(data.data)
                                .ok('OK')
                                .targetEvent(originatorEv)

                        );

                    } else {
                        $mdDialog.show(
                            $mdDialog.alert()
                                .title('STALK SAYS')
                                .textContent(data.message)
                                .ok('OK')
                                .targetEvent(originatorEv)

                        );
                    }

                    $window.location.reload();
                })
                .error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                });

        };

        this.sendComment = function (forumId, comment) {
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = { 'forumId': forumId, 'comment': comment };
            $http.post('php/sendComment.php', data).success(function (data, status, headers, config) {
            
                if (data.message == "Success") {

                } else {
                    $window.location.reload();
                }

            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
            });
        };

        $scope.uploadImage = function (files) {
            //console.log("trying to upload");
            var fd = new FormData();
            //Take the first selected file
            fd.append("image", files[0]);

            $http.post("php/uploadImage.php", fd, {
                withCredentials: true,
                headers: { 'Content-Type': undefined },
                transformRequest: angular.identity
            }).success(function (data, status, headers, config) {
                if (data.message == "Success") {

                } else {

                }

            }).error(function (data, status, headers, config) {
                //console.log(data);
            });
        };
        //functions above this
        $scope.uploadProfileImage = function (files) {
            var oldImg = $scope.userImage;
            $scope.userImage = "img/loading.gif";
            //console.log("trying to upload profile image");
            var fd = new FormData();
            var exts = ["jpeg", "jpg", "png", "gif"];
            //Take the first selected file
            fd.append("image", files[0]);
            //console.log("file size " + files[0].size);
            if (files[0].size < 2097152 && exts.includes(files[0].name.substr(files[0].name.lastIndexOf('.') + 1))) {
                $http.post("php/uploadProfilePicture.php", fd, {
                    withCredentials: true,
                    headers: { 'Content-Type': undefined },
                    transformRequest: angular.identity
                }).success(function (data, status, headers, config) {
                    if (data.message == "Success") {
                        $scope.getProfilePicture($scope.userId);

                    } else {
                        $scope.userImage = oldImg;
                        //extError sizeErr
                        var err = "Internal error please try later !";
                        try {
                            if (data.data.extError)
                                err = data.data.extError;
                            if (data.data.sizeErr)
                                err = data.data.sizeErr;
                        } catch{
                            err = "File size must be less than 2MB";
                        }
                        $mdDialog.show(
                            $mdDialog.alert()
                                .title('STALK SAYS')
                                .textContent(err)
                                .ok('OK')
                                .targetEvent(originatorEv)
                        );
                    }

                }).error(function (data, status, headers, config) {
                    //console.log(data);
                    $scope.userImage = oldImg;
                });
            } else {
                $scope.userImage = oldImg;
                $mdDialog.show(
                    $mdDialog.alert()
                        .title('STALK SAYS')
                        .textContent("File size must be less than 2MB \nand only choose a JPEG, PNG or GIF file")
                        .ok('OK')
                        .targetEvent(originatorEv)
                );
            }

        };


        this.updateUserInfo = function (userTitle, mobile, opassword, npassword, discription) {
            $scope.wait = true;
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = {
                'gender': userTitle,
                'npassword': npassword,
                'mobile': mobile,
                'opassword': opassword,
                'discription': discription
            };

            $http.post('php/updateUserInfo.php', data)

                .success(function (data, status, headers, config) {
                    
                    $scope.loginError = "";
                    if (data.message == "Success") {
                        $scope.mobile = data.data.mobile;
                        $scope.discription = data.data.discription;
                        $scope.userTitle = data.data.userTitle;
                    }

                    else {
                        $scope.loginError = data.message;
                        //console.log($scope.loginError);
                    }
                    $scope.wait = false;
                })
                .error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                    $scope.wait = false;
                });

        };

        $scope.addToContacts = function (userId, atUserIndex,isConnected) {

            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';

            data = {
                'userId': userId,
                'isConnected':isConnected
            };

            $http.post('php/addToContact.php', data)
                .success(function (data, status, headers, config) {
                    $scope.loginError = "";
                    if (data.message == "Success") {
                        if(!isConnected){
                        $scope.myContacts.push(data.data);
                        $scope.users[atUserIndex].isConnected = true;
                        }else{
                            //console.log("rem contact "+ data.data.userId);
                            var index = $scope.myContacts.findIndex(temp => temp.userId === data.data.userId);            
                            if(index>-1)
                            $scope.myContacts.splice(index, 1);
                            $scope.users[atUserIndex].isConnected = false;
                        }    
                    }

                    else if (data.message == "Contact already exists") {
                        //$scope.myContacts = data.data.myContacts;
                        $scope.users[atUserIndex].isConnected = true;
                    }
                    $scope.wait = false;
                })
                .error(function (data, status, headers, config) {
                    //console.log(data);
                    $window.location.reload();
                    $scope.wait = false;
                });

        };

        //functions here
        $scope.shareForum = function(forumId,msg){
            angular.forEach($scope.visibilityArray, function (value, index) {
                $scope.sendMessage(value,msg+'[['+forumId+']]');
            });
            $scope.visibilityArray=[];
        }

        $scope.clearvisibilityArray = function(){
            $scope.visibilityArray=[];
        }

        $scope.sendMessage = function (userId, message) {
            
            if(message.trim()!=''){
                console.log("message length "+message.length);
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = { 'userId': userId, 'message': message,'fileUrl':'','file':false  };
            $http.post('php/sendMessage.php', data).success(function (data, status, headers, config) {
                if (data.message == "Success") {

                } else {

                }
            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
            });
        }
        };

        $scope.modifyMember = function(forumId,members){
            if(members.length>=1){
                    var ind = members.indexOf($scope.userId);
                    if(ind<0){
                        members.push($scope.userId);
                    }
            }

            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = { 'forumId': forumId, 'members': members };
            $http.post('php/modifyVisibility.php', data).success(function (data, status, headers, config) {

                if(data.message == "Success") {
                        $scope.message("Members are modified");
                } else {
                    $scope.message(data.message);
                }

            }).error(function (data, status, headers, config) {
                //console.log(data);
                $window.location.reload();
            });
        };
        // functions end
        this.reportForum = function(forumId,reportMsg){
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = { 'forumId': forumId ,"reportMsg":reportMsg };
            $http.post('php/reportForum.php', data).success(function (data, status, headers, config) {
                if (data.message == "Success") {

                } else {

                }
            }).error(function (data, status, headers, config) {
                $window.location.reload();
            });
              
        };



        $scope.sendMessage = function (userId, message,fileUrl) {
            console.log(((''+message+'').trim()+'').length);
            if( (message!=undefined && ((''+message+'').trim()+'').length>0) || fileUrl!=undefined )
            
            {
            $http.defaults.headers.post['Content-Type'] = 'application/json; charset=utf-8';
            data = { 'userId': userId, 'message': message ,'fileUrl':fileUrl,'file':true };
            $http.post('php/sendMessage.php', data).success(function (data, status, headers, config) {
                if (data.message == "Success") {

                } else {

                }
                console.log(data.message);
            }).error(function (data, status, headers, config) {
                $window.location.reload();
            });
        }
        };


        $scope.sendFile = function(userId,message){
            // Create a virtual input element.
            var input2 = document.createElement('input');
            input2.type = 'file';
            //input2.accept = "*/*";
  
            input2.onchange = function() {
              
            //   console.log("trying to upload");
              if (this.files && this.files[0]) {
                 
              var fd = new FormData();
              //Take the first selected file
              fd.append("image", this.files[0]);
              fd.append("userId",userId);
              $http.post("php/uploadFile.php", fd, {
                  withCredentials: true,
                  headers: { 'Content-Type': undefined },
                  transformRequest: angular.identity
              }).success(function (data, status, headers, config) {
                  
                  if (data.message == "Success") {
                      //$editor().wrapSelection('insertHtml', "<a target='_blank' href='php/imageRetriver.php?imageId="+data.data+"'>view file</a>", true);
                      $scope.sendMessage(userId,message,
                        
                        "<a target='_blank' href='php/imageRetriver.php?imageId="+data.data+"'>view file "+input2.files[0].name +"</a>"
                        );
                      
                  } else {
                      $window.alert("Some thing went wrong "+ data.message);
                  }
  
              }).error(function (data, status, headers, config) {
                  console.log(data);
                  $window.location.reload();
              });}
            };
            input2.click();

        };



        $scope.sendImage = function(userId,message){
            var input = document.createElement('input');
            input.type = 'file';
            input.accept = "image/jpg,image/png,image/gif,image/jpeg";
            
            input.onchange = function() {
              var reader = new FileReader();
  
              if (this.files && this.files[0]) {
              
              var fd = new FormData();
              //Take the first selected file
              fd.append("image", this.files[0]);
              fd.append("userId",userId);  
              $http.post("php/uploadImage.php", fd, {
                  withCredentials: true,
                  headers: { 'Content-Type': undefined },
                  transformRequest: angular.identity
              }).success(function (data, status, headers, config) {
                  
                  if (data.message == "Success") {
                    
                      $scope.sendMessage(userId,message,
                        
                        "<a target='_blank' href='php/imageRetriver.php?imageId="+data.data+"' ><img alt='Login to see images' style='height:200px;width:200px' src='php/imageRetriver.php?imageId="+data.data+"'></a>"
                        );

                  } else {
                      $window.alert("Some thing went wrong\n"+data.message);
                  }
  
              }).error(function (data, status, headers, config) {
                  $window.location.reload();
  
              });
              }
            };
            input.click();
        };

    }
);

